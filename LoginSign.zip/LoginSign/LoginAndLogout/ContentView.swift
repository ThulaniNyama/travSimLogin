//
//  ContentView.swift
//  LoginAndLogout
//
//  Created by Thanyani on 2020/09/03.
//  Copyright © 2020 Thanyani. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        LoginAndSignUP()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
